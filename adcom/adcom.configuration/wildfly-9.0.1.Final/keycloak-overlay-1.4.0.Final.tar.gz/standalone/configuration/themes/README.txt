Themes to configure the look and feel of login pages and account management console. It's not recommended to
modify existing the built-in themes, instead you should create a new theme that extends a built-in theme. See the theme
section in the documentation for more details.