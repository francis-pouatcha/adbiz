Any provider implementation jars and libraries in this folder will be loaded by Keycloak. See the providers
section in the documentation for more details.